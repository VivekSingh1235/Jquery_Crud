﻿$(document).ready(function () {
    ShowEmployeeData();
});

function ShowEmployeeData() {
    $.ajax({
        url: '/Ajax/EmployeeList',
        type: 'GET',
        dataType: 'json',
        contentType: 'application/json;charset=utf-8;',
        success: function (result, status, xhr) {
            var object = '';
            $.each(result, function (index, item) {
                object += '<tr>';
                object += '<td>' + item.id + '</td>';
                object += '<td>' + item.name + '</td>';
                object += '<td>' + item.email + '</td>';
                object += '<td>' + item.city + '</td>';
                object += '<td><a href="#" class="btn btn-primary">Edit</a> || <a href="#" class="btn btn-danger" onclick="Delete(' + item.id + ')">Delete</a></td>';
                object += '</tr>';
            });
            $('#table_data').html(object);
        },
        error: function () {
            alert("Data can't be retrieved.");
        }
    });
}

$('#btnAddEmployee').on('click', function () {
    $('#EmployeeMadal').modal('show');
});

function AddEmployee() {
    var objData = {
        Id: $('#EmployeeId').val(),
        Name: $('#Name').val(),
        Email: $('#Email').val(),
        City: $('#City').val()
    };

    $.ajax({
        url: '/Ajax/AddEmployee',
        type: 'POST',
        data: objData,
        success: function () {
            alert('Data Saved');
            // Refresh the employee data table after adding new employee
            ShowEmployeeData();
        },
        error: function () {
            alert('Data cannot be saved.');
        }
    });
}

function Delete(id) {

    if (confirm('Are you sure ,You Want to delete this record')){

        $.ajax({
            url: '/Ajax/DeleteEmployee?id=' + id,
            type: 'DELETE',
            success: function () {
                alert('Record deleted');
                // Refresh the employee data table
                ShowEmployeeData();
            },
            error: function () {
                alert('Failed to delete! ');
            }
        });
    }

    }



