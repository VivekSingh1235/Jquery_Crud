﻿using CRUDAJAX.Models;
using Microsoft.EntityFrameworkCore;
namespace CRUDAJAX.Data
{



    // ApplicationContext.cs
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<Employee> Employees { get; set; }
        // Add other DbSets for other models if needed
    }


}
