﻿using CRUDAJAX.Data;
using CRUDAJAX.Models;
using Microsoft.AspNetCore.Mvc;

namespace CRUDAJAX.Controllers.Ajax
{
    public class AjaxController : Controller
    {
        private readonly ApplicationDbContext context;

        public AjaxController(ApplicationDbContext context)
        {
            this.context = context;
        }

        public IActionResult Index()
        {
            return View();
        }
        // Action to get list of employees
        public JsonResult EmployeeList()
        {
            // Implementation to retrieve employee list from database
            var data = context.Employees.ToList();
            return new JsonResult(data);
        }
        [HttpPost]
        public IActionResult AddEmployee(Employee employee)
        {
            var emp = new Employee()
            {
                Id = employee.Id,
                Name = employee.Name,
                Email = employee.Email,
                City = employee.City,

            };

            if (emp.Id == 0)
            {
                context.Employees.Add(emp);
                context.SaveChanges();
            }
            return new JsonResult("Data is  Save");
        }
         [HttpDelete]
        public IActionResult DeleteEmployee(int id)
        {
            var employee = context.Employees.FirstOrDefault(e => e.Id == id);

            {
                context.Employees.Remove(employee);
                context.SaveChanges();
                return new JsonResult("Employee deleted successfully");
            }
            return new JsonResult("Employee not found");
        }
    }
}
